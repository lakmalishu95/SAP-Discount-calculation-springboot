package com.sapdiscountapp.calculatediscount.model;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;

@Entity
@Getter
@Setter
@Table(name = "Schema_Detail")
public class SchemaDetail {

    @Id
    @Column(name = "schema_id")
    private int schema_id;
    @Column(name = "value")
    private int value;

    @ManyToOne
    @JoinColumn(name = "time_slots", referencedColumnName = "id")
    private TimeSlots timeSlots;

    @Column(name = "material_group")
    private int material_group;

}
