package com.sapdiscountapp.calculatediscount.repository;

import com.sapdiscountapp.calculatediscount.model.MaterialGroup;
import com.sapdiscountapp.calculatediscount.model.SchemaDetail;
import com.sapdiscountapp.calculatediscount.model.TimeSlots;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SchemaDetailRepo extends JpaRepository<SchemaDetail, Integer> {
    SchemaDetail findByTimeSlotsAndMaterialGroup(TimeSlots timeSlots, MaterialGroup materialGroup);
}
