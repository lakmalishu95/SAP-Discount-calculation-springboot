package com.sapdiscountapp.calculatediscount.repository;

import com.sapdiscountapp.calculatediscount.model.Invoice;
import com.sapdiscountapp.calculatediscount.model.InvoiceDetail;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface InvoiceDetailRepo extends JpaRepository<InvoiceDetail, Integer> {

    List<InvoiceDetail> findByInvoice(Invoice invoice);
}
