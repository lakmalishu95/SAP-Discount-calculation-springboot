package com.sapdiscountapp.calculatediscount;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CalculatediscountApplication {

	public static void main(String[] args) {
		SpringApplication.run(CalculatediscountApplication.class, args);
	}

}
