package com.sapdiscountapp.calculatediscount.model;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Getter
@Setter
@Table(name = "Customer")
public class Customers {

    @Id
    @Column(name = "customer_code")
    private int customerCode;
    @Column(name = "customer_name")
    private String customerName;
    @Column(name = "customer_group")
    private String customerGroup;

}
