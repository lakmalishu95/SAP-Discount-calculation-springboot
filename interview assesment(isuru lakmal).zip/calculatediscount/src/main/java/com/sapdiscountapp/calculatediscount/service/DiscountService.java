package com.sapdiscountapp.calculatediscount.service;

import com.sapdiscountapp.calculatediscount.dto.DiscountDto;
import com.sapdiscountapp.calculatediscount.model.*;
import com.sapdiscountapp.calculatediscount.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

@Service
public class DiscountService {

    @Autowired
    CustomerRepo customerRepo;

    @Autowired
    InvoiceRepo invoiceRepo;

    @Autowired
    InvoiceDetailRepo invoiceDetailRepo;

    @Autowired
    MaterialGroupRepo materialGroupRepo;

    @Autowired
    SchemaDetailRepo schemaDetailRepo;

    @Autowired
    TimeSlotRepo timeSlotRepo;


    public List<DiscountDto> generateDiscount(int customerCode) {

        Customers customer = customerRepo.findById(customerCode).get();

        List<Invoice> invoiceList = invoiceRepo.findByCustomerCode(customerCode);


        List<DiscountDto> discountDtoList = new ArrayList<>();

        List<Integer> discounts = new ArrayList<>();
        discounts.add(0);

        invoiceList.forEach(invoice -> {
            int setOfDate = getMonthFromDate(invoice.getInvoiceSetOff());

            TimeSlots timeSlots = timeSlotRepo.findBySetOffDate(setOfDate);

            List<InvoiceDetail> invoiceDetail = invoiceDetailRepo.findByInvoice(invoice);

            invoiceDetail.forEach(invoicerow -> {
                SchemaDetail schemaDetail =  schemaDetailRepo.findByTimeSlotsAndMaterialGroup(timeSlots,invoicerow.getMaterialGroup());
                int discount = discounts.get(0) + invoicerow.getQuantity() * schemaDetail.getValue();
                discounts.set(0, discount);

            });

            DiscountDto discountDto = new DiscountDto();
            discountDto.setCustomerCode(customer.getCustomerCode());
            discountDto.setCustomerName(customer.getCustomerName());
            discountDto.setDiscount(discounts.get(0));
            discountDto.setInvoiceNumber(invoice.getInvNumber());
            discountDtoList.add(discountDto);
        });

        return  discountDtoList;

    }

    private int getMonthFromDate(Date date) {


        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        int month = calendar.get(Calendar.MONTH) + 1;
        return month;

    }


}
