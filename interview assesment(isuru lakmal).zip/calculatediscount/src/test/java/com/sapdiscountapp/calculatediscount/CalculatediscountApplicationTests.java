package com.sapdiscountapp.calculatediscount;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CalculatediscountApplicationTests {

	@Test
	void contextLoads() {
	}

}
